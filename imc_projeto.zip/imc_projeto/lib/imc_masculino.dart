import 'package:flutter/material.dart';

class ImcMasculino extends StatefulWidget {
  const ImcMasculino({super.key});

  @override
  State<ImcMasculino> createState() => ImcMasculinoState();
}

class ImcMasculinoState extends State<ImcMasculino> {
  TextEditingController heightController = TextEditingController();
  TextEditingController weightController = TextEditingController();
  bool isMale = true;
  String result = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calcular IMC Masculino'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            
            ElevatedButton(onPressed: () {
              Navigator.pushNamed(context, '/imc_feminino.dart');
            }, child: Text('IMC Feminino')),

            TextField(
              controller: heightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Sua Altura (cm)'),
            ),
            TextField(
              controller: weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Seu Peso (kg)'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                calculateBMI();
              },
              child: Text('Calcular IMC'),
            ),
            SizedBox(height: 20),
            Text('Resultado: $result'),
          ],
        ),
      ),
    );
  }

  void calculateBMI() {
    double height = double.parse(heightController.text);
    double weight = double.parse(weightController.text);

    double bmi = weight / ((height / 100) * (height / 100));

    setState(() {
      result = 'IMC: ${bmi.toStringAsFixed(2)}\n';
      if (isMale == true) {
        result += 'Categoria: ${interpretResultMale(bmi)}';
      } else {
        result += 'Categoria: ${interpretResultFemale(bmi)}';
      }
    });
  }

  String interpretResultMale(double bmi) {
    if (bmi < 20.7) {
      return 'Abaixo do peso';
    } else if (bmi >= 20.7 && bmi < 26.4) {
      return 'Peso normal';
    } else if (bmi >= 26.4 && bmi < 27.8) {
      return 'Marginalmente acima do peso';
    } else if (bmi >= 27.8 && bmi < 31.1) {
      return 'Acima do peso ideal';
    } else {
      return 'Obeso';
    }
  }

  String interpretResultFemale(double bmi) {
    if (bmi < 19.1) {
      return 'Abaixo do peso';
    } else if (bmi >= 19.1 && bmi < 25.8) {
      return 'Peso normal';
    } else if (bmi >= 25.8 && bmi < 27.3) {
      return 'Marginalmente acima do peso';
    } else if (bmi >= 27.3 && bmi < 32.3) {
      return 'Acima do peso ideal';
    } else {
      return 'Obeso';
    }
  }
}
