import 'package:flutter/material.dart';

class Participantes extends StatefulWidget {
  const Participantes({super.key});

  @override
  State<Participantes> createState() => _ParticipantesState();
}

class _ParticipantesState extends State<Participantes> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Participantes do Projeto"),
        ),
        body: Column(
          children: <Widget>[
            ElevatedButton(onPressed: () {
              Navigator.pushNamed(context, '/imc_masculino.dart');
            }, child: Text('IMC Masculino')),
            Text("Kevin Silva Estrela RA: 1431432312035 | Vitor Aquino dos Santos RA: 1431432312010"),
          ],
          
        ));
  }
}

