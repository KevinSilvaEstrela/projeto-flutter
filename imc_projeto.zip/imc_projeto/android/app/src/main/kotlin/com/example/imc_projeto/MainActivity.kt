package com.example.imc_projeto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
